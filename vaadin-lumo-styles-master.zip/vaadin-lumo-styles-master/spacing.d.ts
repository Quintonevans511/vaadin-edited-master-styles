import {CSSResult} from 'lit-element';

export const spacing: CSSResult;
