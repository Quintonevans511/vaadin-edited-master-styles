import {CSSResult} from 'lit-element';

export const font: CSSResult;

export const typography: CSSResult;
