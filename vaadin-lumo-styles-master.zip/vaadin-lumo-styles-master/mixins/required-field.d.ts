import {CSSResult} from 'lit-element';

export const requiredField: CSSResult;
