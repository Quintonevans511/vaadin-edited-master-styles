import {CSSResult} from 'lit-element';

export const menuOverlay: CSSResult;
