import {CSSResult} from 'lit-element';

export const fieldButton: CSSResult;
