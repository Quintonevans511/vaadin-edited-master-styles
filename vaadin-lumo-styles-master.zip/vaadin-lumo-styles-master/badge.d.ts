import {CSSResult} from 'lit-element';

export const badge: CSSResult;
