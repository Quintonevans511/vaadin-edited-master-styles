import {CSSResult} from 'lit-element';

export const colorBase: CSSResult;

export const color: CSSResult;

export const colorLegacy: CSSResult;
